// src/main/java/com/university/fuel/entity/Role.java
package com.university.fuel.entity;

public enum Role {
    CHAUFFEUR,
    CHEF_CHALOI,
    RESPONSABLE_CARBURANT,
    DAF,
    ADMIN
}