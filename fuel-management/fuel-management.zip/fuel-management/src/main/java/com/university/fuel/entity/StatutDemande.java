// src/main/java/com/university/fuel/entity/StatutDemande.java
package com.university.fuel.entity;

public enum StatutDemande {
    EN_ATTENTE_CHEF,
    EN_ATTENTE_RESPONSABLE,
    EN_ATTENTE_DAF,
    APPROUVEE,
    REJETEE
}