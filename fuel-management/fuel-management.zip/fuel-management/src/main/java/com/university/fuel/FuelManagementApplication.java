package com.university.fuel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelManagementApplication.class, args);
	}

}
